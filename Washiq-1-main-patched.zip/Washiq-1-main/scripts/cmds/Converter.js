const axios = require("axios");

/**
 * @author Washiq Adnan
 * @description Professional Converter for Washiq AI (v9.0)
 */

module.exports = {
    config: {
        name: "converter",
        aliases: ["cb", "cbh"],
        version: "9.0",
        author: "Washiq Adnan",
        countDown: 5,
        role: 0,
        category: "tools",
        guide: { 
            en: "{pn}cb [Banglish] - পুরো টেক্সট বাংলা হবে\n{pn}cbh [Bangla] - পুরো টেক্সট বাংলিশ হবে" 
        }
    },

    onStart: async function ({ api, event, args, message }) {
        const commandUsed = event.body.split(/\s+/)[0].toLowerCase().substring(1);
        let text = args.join(" ");

        if (event.type === "message_reply") {
            text = event.messageReply.body;
        }

        if (!text) {
            return message.reply(`🐤 | অনুগ্রহ করে কিছু লিখুন!\nব্যবহার: /${commandUsed} [আপনার টেক্সট]`);
        }

        // CB: Banglish to Bangla (সম্পূর্ণ টেক্সট ফিক্স)
        if (commandUsed === "cb") {
            try {
                api.setMessageReaction("⌛", event.messageID, () => {}, true);
                
                // Google API-তে বড় টেক্সট পাঠানোর জন্য সঠিক মেথড
                const res = await axios.get(`https://www.google.com/inputtools/request?ime=transliteration_en_bn&num=1&cp=0&cs=0&ie=utf-8&oe=utf-8&app=jsapi&text=${encodeURIComponent(text)}`);
                
                if (res.data && res.data[0] === "SUCCESS") {
                    // পুরো টেক্সট জয়েন করে আউটপুট দেওয়া
                    const converted = res.data[1].map(item => item[1][0]).join("");
                    api.setMessageReaction("✅", event.messageID, () => {}, true);
                    return message.reply(converted);
                }
            } catch (e) {
                api.setMessageReaction("❌", event.messageID, () => {}, true);
                return message.reply("🥺 বড় টেক্সট কনভার্ট করতে সমস্যা হয়েছে।");
            }
        }

        // CBH: Bangla to Banglish (বানান ফিক্স)
        if (commandUsed === "cbh") {
            try {
                const result = transliterateToUltra(text);
                return message.reply(result);
            } catch (e) {
                return message.reply("🥺 বাংলিশ করতে ত্রুটি হয়েছে।");
            }
        }
    }
};

function transliterateToUltra(input) {
    // চিরদিন এবং অন্যান্য বানানের বিশেষ সমাধান
    const MULTI = [
        ["চিরদিন", "chirodin"], ["সোনার", "sonar"], ["বাংলা", "bangla"], 
        ["আকাশ", "akash"], ["বাতাস", "batash"], ["প্রা", "pra"], 
        ["মরি", "mori"], ["হায়", "hay"], ["বাঁশি", "bashi"]
    ];

    const VOWELS = { "অ": "o", "আ": "a", "ই": "i", "ঈ": "i", "উ": "u", "ঊ": "u", "এ": "e", "ঐ": "oi", "ও": "o", "ঔ": "ou" };
    const KARS = { "া": "a", "ি": "i", "ী": "i", "ু": "u", "ূ": "u", "ে": "e", "ৈ": "oi", "ো": "o", "ৌ": "ou" };
    const CONS = { 
        "ক": "k", "খ": "kh", "গ": "g", "ঘ": "gh", "চ": "ch", "ছ": "ch", "জ": "j", "ঝ": "jh",
        "ট": "t", "ঠ": "th", "ড": "d", "ঢ": "dh", "ত": "t", "থ": "th", "দ": "d", "ধ": "dh", 
        "ন": "n", "প": "p", "ফ": "f", "ব": "b", "ভ": "bh", "ম": "m", "য": "j", "র": "r", "ল": "l", 
        "শ": "sh", "ষ": "sh", "স": "s", "হ": "h", "ড়": "r", "ঢ়": "rh", "য়": "y", "ং": "ng", "ঙ": "ng"
    };

    let temp = input;
    for (const [bn, rom] of MULTI) temp = temp.split(bn).join(rom);
    
    let out = "";
    const chars = Array.from(temp);
    for (let i = 0; i < chars.length; i++) {
        const ch = chars[i];
        if (ch <= 'z' && ch >= 'a') { out += ch; continue; }

        const next = chars[i+1];
        if (VOWELS[ch]) {
            out += VOWELS[ch];
        } else if (CONS[ch]) {
            if (next === "্") { out += CONS[ch]; i++; }
            else if (KARS[next]) { out += CONS[ch] + KARS[next]; i++; }
            else if (!next || " ।,:;!?—\n".includes(next) || "শনলসরত".includes(ch)) { 
                out += CONS[ch]; 
            }
            else { out += CONS[ch] + "o"; }
        } else {
            out += (ch === "।" ? "." : ch);
        }
    }
    return out.replace(/oo+/g, "o").replace(/hayo/g, "hay").trim();
          }
