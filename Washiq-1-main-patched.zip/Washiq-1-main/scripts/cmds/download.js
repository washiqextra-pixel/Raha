const fs = require("fs");
const { downloadVideo } = require("sagor-video-downloader");

// 🎀 Fancy font converter (supports A-Z a-z 0-9; others stay same)
function toFancy(str = "") {
  const map = {
    A:"𝓐",B:"𝓑",C:"𝓒",D:"𝓓",E:"𝓔",F:"𝓕",G:"𝓖",H:"𝓗",I:"𝓘",J:"𝓙",K:"𝓚",L:"𝓛",M:"𝓜",
    N:"𝓝",O:"𝓞",P:"𝓟",Q:"𝓠",R:"𝓡",S:"𝓢",T:"𝓣",U:"𝓤",V:"𝓥",W:"𝓦",X:"𝓧",Y:"𝓨",Z:"𝓩",
    a:"𝓪",b:"𝓫",c:"𝓬",d:"𝓭",e:"𝓮",f:"𝓯",g:"𝓰",h:"𝓱",i:"𝓲",j:"𝓳",k:"𝓴",l:"𝓵",m:"𝓶",
    n:"𝓷",o:"𝓸",p:"𝓹",q:"𝓺",r:"𝓻",s:"𝓼",t:"𝓽",u:"𝓾",v:"𝓿",w:"𝔀",x:"𝔁",y:"𝔂",z:"𝔃",
    0:"𝟶",1:"𝟷",2:"𝟸",3:"𝟹",4:"𝟺",5:"𝟻",6:"𝟼",7:"𝟽",8:"𝟾",9:"𝟿"
  };
  return String(str).split("").map(ch => map[ch] || ch).join("");
}

module.exports = {
  config: {
    name: "download",
    version: "1.4",
    author: "Washiq",
    countDown: 5,
    role: 0,
    shortDescription: "Auto-download & send videos silently (no messages)",
    category: "media",
  },

  onStart: async function () {},

  onChat: async function ({ api, event }) {
    const threadID = event.threadID;
    const messageID = event.messageID;
    const message = event.body || "";

    const linkMatches = message.match(/(https?:\/\/[^\s]+)/g);
    if (!linkMatches || linkMatches.length === 0) return;

    const uniqueLinks = [...new Set(linkMatches)];

    // 🎀 start
    api.setMessageReaction("🎀", messageID, () => {}, true);

    let successCount = 0;
    let failCount = 0;

    for (const url of uniqueLinks) {
      // ⏳ downloading now
      api.setMessageReaction("⏳", messageID, () => {}, true);

      try {
        const { title, filePath } = await downloadVideo(url);
        if (!filePath || !fs.existsSync(filePath)) throw new Error("Download failed");

        const stats = fs.statSync(filePath);
        const fileSizeInMB = stats.size / (1024 * 1024);

        // >25MB হলে silent fail
        if (fileSizeInMB > 25) {
          fs.unlinkSync(filePath);
          failCount++;
          continue;
        }

        const fancyBody =
`✅ ${toFancy("Your video is ready!")}

━━━━━━━━━━━━━━━━━━
👤 ${toFancy("Owner")}: ${toFancy("Washiq")}
🎬 ${toFancy("Title")}: ${toFancy(title || "Video File")}
📦 ${toFancy("Size")}: ${toFancy(fileSizeInMB.toFixed(2))} ${toFancy("MB")}
━━━━━━━━━━━━━━━━━━

${toFancy("Enjoy!")}`;

        await api.sendMessage(
          {
            body: fancyBody,
            attachment: fs.createReadStream(filePath),
          },
          threadID,
          () => fs.unlinkSync(filePath)
        );

        successCount++;

        // 🤔✅ style: first 🤔 then ✅
        api.setMessageReaction("🤔", messageID, () => {}, true);
        api.setMessageReaction("✅", messageID, () => {}, true);

      } catch (e) {
        failCount++;
        // ডাউনলোড না হলে ⛔
        api.setMessageReaction("⛔", messageID, () => {}, true);
      }
    }

    // শেষ রিঅ্যাকশন: যদি কোনো fail থাকে ⛔, না হলে ✅
    if (failCount > 0 && successCount === 0) {
      api.setMessageReaction("⛔", messageID, () => {}, true);
    } else {
      api.setMessageReaction("✅", messageID, () => {}, true);
    }
  },
};
