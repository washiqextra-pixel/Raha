const fs = require("fs-extra");
const path = require("path");

const { commands, aliases } = global.GoatBot;

module.exports = {
  config: {
    name: "help",
    aliases: ["menu", "commands"],
    version: "5.9",
    author: "Washiq",
    countDown: 5,
    role: 0,
    shortDescription: { en: "View command list with pages + command details" },
    longDescription: { en: "Shows all commands by category with page system and fancy style" },
    category: "info",
    guide: { en: "{pn} [page] / {pn} <cmdName>" },
    priority: 1
  },

  onStart: async function ({ message, args, event, threadsData, role }) {
    const { threadID } = event;
    const threadData = await threadsData.get(threadID);
    const globalPrefix = global.GoatBot.config.prefix;
    const boxPrefix = threadData.data?.prefix || globalPrefix;

    const fancyFont = (text) => {
      const fonts = {
        a: "𝐚", b: "𝐛", c: "𝐜", d: "𝐝", e: "𝐞", f: "𝐟", g: "𝐠", h: "𝐡", i: "𝐢", j: "𝐣", k: "𝐤", l: "𝐥", m: "𝐦",
        n: "𝐧", o: "𝐨", p: "𝐩", q: "𝐪", r: "𝐫", s: "𝐬", t: "𝐭", u: "𝐮", v: "𝐯", w: "𝐰", x: "𝐱", y: "𝐲", z: "𝐳",
        A: "𝐀", B: "𝐁", C: "𝐂", D: "𝐃", E: "𝐄", F: "𝐅", G: "𝐆", H: "𝐇", I: "𝐈", J: "𝐉", K: "𝐊", L: "𝐋", M: "𝐌",
        N: "𝐍", O: "𝐎", P: "𝐏", Q: "𝐐", R: "𝐑", S: "𝐒", T: "𝐓", U: "𝐔", V: "𝐕", W: "𝐖", X: "𝐗", Y: "𝐘", Z: "𝐙",
        "0": "𝟎", "1": "𝟏", "2": "𝟐", "3": "𝟑", "4": "𝟒", "5": "𝟓", "6": "𝟔", "7": "𝟕", "8": "𝟖", "9": "𝟗"
      };
      return String(text).split("").map(ch => fonts[ch] || ch).join("");
    };

    const roleTextToString = (r) => {
      switch (r) {
        case 0: return "𝟎 (𝐀𝐥𝐥 𝐮𝐬𝐞𝐫𝐬)";
        case 1: return "𝟏 (𝐆𝐫𝐨𝐮𝐩 𝐚𝐝𝐦𝐢𝐧𝐬)";
        case 2: return "𝟐 (𝐁𝐨𝐭 𝐚𝐝𝐦𝐢𝐧)";
        default: return "𝐔𝐧𝐤𝐧𝐨𝐰𝐧";
      }
    };

    const getCommandCategories = () => {
      const cats = {};
      for (const [name, cmd] of commands) {
        if (cmd.config?.role > 0 && role < cmd.config.role) continue;
        const category = cmd.config?.category || "Uncategorized";
        cats[category] = cats[category] || { commands: [] };
        if (!cats[category].commands.includes(name)) cats[category].commands.push(name);
      }
      return cats;
    };

    const generateCommandList = (page = 1, categories) => {
      const categoryKeys = Object.keys(categories).sort((a, b) => a.localeCompare(b));
      const categoriesPerPage = 10;
      const totalPages = Math.max(1, Math.ceil(categoryKeys.length / categoriesPerPage));
      const currentPage = Math.max(1, Math.min(page, totalPages));
      const startIndex = (currentPage - 1) * categoriesPerPage;
      const currentCategories = categoryKeys.slice(startIndex, startIndex + categoriesPerPage);

      let msg = "୨୧ ─·· 🍰 𝐂𝐨𝐦𝐦𝐚𝐧𝐝 𝐌𝐞𝐧𝐮 🍰 ··─ ୨୧\n\n";
      msg += `🍓 ${fancyFont("𝐂𝐨𝐦𝐦𝐚𝐧𝐝𝐬")}: ${commands.size}\n`;
      msg += `🌐 ${fancyFont("𝐒𝐲𝐬𝐭𝐞𝐦")}: ${globalPrefix}\n`;
      msg += `🛸 ${fancyFont("𝐁𝐨𝐱")}: ${boxPrefix}\n`;
      msg += `📖 ${fancyFont("𝐏𝐚𝐠𝐞")}: ${currentPage} / ${totalPages}\n\n`;

      for (const category of currentCategories) {
        msg += `╭・─「 🌸 ${fancyFont(category.toUpperCase())} 🌸 」\n`;
        const names = categories[category].commands.sort((a, b) => a.localeCompare(b));
        const fancyNames = names.map(n => fancyFont(n));
        for (let i = 0; i < fancyNames.length; i += 3) {
          msg += `│  🎀 ${fancyNames.slice(i, i + 3).join(" ✧ ")}\n`;
        }
        msg += `╰・─── ⬦ 🍓 ⬦ ───・\n\n`;
      }

      msg += `╭─⋅──⋅୨♡୧⋅──⋅─\n`;
      msg += `│ 📝 ${fancyFont("𝐑𝐞𝐩𝐥𝐲 𝐰𝐢𝐭𝐡 𝐩𝐚𝐠𝐞 𝐧𝐮𝐦𝐛𝐞𝐫")}\n`;
      msg += `│ 🔍 ${fancyFont("𝐔𝐬𝐞")}: ${boxPrefix}help <cmd>\n`;
      msg += `│ 👑 ${fancyFont("𝐂𝐫𝐞𝐚𝐭𝐨𝐫")}: ${fancyFont("Washiq")}\n`;
      msg += `╰─⋅──⋅୨♡୧⋅──⋅─`;

      return { message: msg, totalPages };
    };

    // নির্দিষ্ট কমান্ডের বিস্তারিত দেখার সময় কোনো GIF থাকবে না (শুধু টেক্সট)
    if (args.length > 0 && isNaN(args[0])) {
      const commandName = args[0].toLowerCase();
      const command = commands.get(commandName) || commands.get(aliases.get(commandName));

      if (!command) return message.reply(`❌ 𝐂𝐨𝐦𝐦𝐚𝐧𝐝 "${commandName}" 𝐧𝐨𝐭 𝐟𝐨𝐮𝐧𝐝.`);

      const cfg = command.config || {};
      const usage = (cfg.guide?.en || cfg.guide || "No guide")
        .replace(/{pn}/g, boxPrefix + cfg.name)
        .replace(/{p}/g, boxPrefix)
        .replace(/{n}/g, cfg.name);

      const detailMsg = 
`╭・─「 🌸 ${fancyFont("𝐀𝐁𝐎𝐔𝐓 " + cfg.name.toUpperCase())} 🌸 」
│ 🎀 ${fancyFont("𝐃𝐞𝐬𝐜𝐫𝐢𝐩𝐭𝐢𝐨𝐧")}: ${cfg.longDescription?.en || cfg.shortDescription?.en || "No description"}
│ 👑 ${fancyFont("𝐀𝐮𝐭𝐡𝐨𝐫")}: ${fancyFont(cfg.author || "Washiq")}
│ ⚙️ ${fancyFont("𝐔𝐬𝐚𝐠𝐞")}: ${usage}
│ 👑 ${fancyFont("𝐎𝐰𝐧𝐞𝐫")}: ${fancyFont("Washiq Adnan")}
│ 📈 ${fancyFont("𝐕𝐞𝐫𝐬𝐢𝐨𝐧")}: ${cfg.version || "1.0"}
│ 🌼 ${fancyFont("𝐏𝐞𝐫𝐦𝐢𝐬𝐬𝐢𝐨𝐧")}: ${roleTextToString(cfg.role ?? 0)}
│ ❤️‍🩹 ${fancyFont("𝐂𝐨𝐨𝐥𝐝𝐨𝐰𝐧")}: ${cfg.countDown || 0}s
╰・─── ⬦ 🍓 ⬦ ───・`;

      return message.reply(detailMsg); // এখানে attachment বাদ দেওয়া হয়েছে
    }

    // মেইন মেনু লিস্ট দেখানোর সময় GIF থাকবে
    const helpGifs = [
      "https://files.catbox.moe/xavz5a.gif",
      "https://files.catbox.moe/blju27.gif"
    ];
    const randomGif = helpGifs[Math.floor(Math.random() * helpGifs.length)];

    const pageNum = parseInt(args[0]) || 1;
    const categories = getCommandCategories();
    const result = generateCommandList(pageNum, categories);

    return message.reply({
      body: result.message,
      attachment: await global.utils.getStreamFromURL(randomGif)
    }, (err, info) => {
      if (!err) {
        global.GoatBot.onReply.set(info.messageID, {
          commandName: this.config.name,
          messageID: info.messageID,
          author: event.senderID
        });
      }
    });
  },

  onReply: async function ({ message, event, Reply, args }) {
    if (event.senderID !== Reply.author) return;
    const page = parseInt(args[0]);
    if (!isNaN(page)) {
      return message.unsend(Reply.messageID).then(() => {
        this.onStart({ message, args: [page], event, threadsData: global.api, role: 0 });
      });
    }
  }
};
          
